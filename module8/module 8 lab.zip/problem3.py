#Zaineb Bonilla
#11/21/2023
#Problem 3 – Write a function that takes a list and prints if the value 5 is in that list.

def checklist(x):
    if 5 in x:
        print("5, is in the list.")
    else:
        print("5, is not in the list.")

y=[1,2,3,4,5]

checklist(y)