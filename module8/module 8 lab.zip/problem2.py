#Zaineb Bonilla
#11/21/2023
#Problem 2 – Write a function that takes two inputs from a user and prints whether
#the sum is greater than 10, less than 10, or equal to 10.


def sum():
    x = int(input('please enter your first number'))

    y = int(input('please enter your second number'))
    sum = x + y
    if sum > 10:
        print("number is greater than 10.")
    elif sum < 10:
        print("number is less than 10")
    else:
        print("number is equal to 10")
sum()

# print(sum(, ))
# print(sum(, ))
# print(sum(, ))
#
# Number1 = int(input('please enter your first number'))
#
# Number2 = int(input('please enter your second number'))